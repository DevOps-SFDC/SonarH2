The best way to understand how the SonarQube Ant Task 2.0+ works is to give a try to the examples following this order:
* /projects/languages/java/ant/java-ant-simple
* java-ant-modules-same-structure
* java-ant-modules-different-structures