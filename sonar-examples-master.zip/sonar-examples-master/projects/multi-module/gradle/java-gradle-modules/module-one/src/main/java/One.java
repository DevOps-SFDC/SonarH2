public class One {
	
  public String message = "";
	
  public String foo() {
    return "foo";
  }
}
