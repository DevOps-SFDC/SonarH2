#define ADD(X, Y) X + Y

int fun(int a, int b);
