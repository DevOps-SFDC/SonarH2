package sonar.examples

class Library {
    boolean someLibraryMethodJUnit() {
        true
    }

    boolean someLibraryMethodSpock() {
        true
    }
}
