package sonar.examples;

class LibraryJava {
    boolean someLibraryMethodJUnit() {
        return true;
    }

    boolean someLibraryMethodSpock() {
        return true;
    }
}
