//
//  Other.h
//  helloworld
//

#import <Foundation/Foundation.h>

@interface Other : NSObject
- (void)sayHello;
@end
